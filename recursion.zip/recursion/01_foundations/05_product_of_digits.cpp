/*
 * Problem: Product of Digits of a Number
 * ------------------------------------------
 * Given N, compute the product of its decimal digits.
 *
 * Approach: Identical decomposition to sum-of-digits, but the
 * combining operator is multiplication and the identity/base case
 * value is 1 (multiplicative identity) rather than 0.
 *
 * Recurrence: T(N) = T(N/10) + O(1)
 * Time Complexity:  O(log10 N)
 * Space Complexity: O(log10 N)
 */
#include <iostream>
using namespace std;

long long productOfDigits(int n) {
    if (n == 0) return 1;
    return (n % 10) * productOfDigits(n / 10);
}

int main() {
    int n = 1234;
    cout << "Product of digits of " << n << " = " << productOfDigits(n) << endl;
    return 0;
}
