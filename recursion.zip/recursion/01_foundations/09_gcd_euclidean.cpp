/*
 * Problem: GCD of Two Numbers (Euclidean Algorithm)
 * ----------------------------------------------------
 * Compute the greatest common divisor of A and B.
 *
 * Approach: Euclid's algorithm rests on the identity
 * gcd(a, b) = gcd(b, a % b), with base case gcd(a, 0) = a.
 * Each recursive step strictly reduces the second argument, and
 * the sequence of remainders is guaranteed to hit 0.
 *
 * Recurrence: T(N) = T(N mod prev) -- amortized logarithmic due to
 * Lame's theorem (relates worst case to consecutive Fibonacci numbers).
 * Time Complexity:  O(log(min(A, B)))
 * Space Complexity: O(log(min(A, B)))
 */
#include <iostream>
using namespace std;

int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

int main() {
    int a = 56, b = 98;
    cout << "GCD(" << a << ", " << b << ") = " << gcd(a, b) << endl;
    return 0;
}
