/*
 * Problem: Sum of Digits of a Number
 * ------------------------------------
 * Given N, compute the sum of its decimal digits.
 *
 * Approach: Peel off the last digit via N % 10, recurse on N / 10
 * (the remaining prefix), and accumulate.
 * Base case: N == 0 contributes 0.
 *
 * Recurrence: T(N) = T(N/10) + O(1)
 * Time Complexity:  O(log10 N)  -- number of digits
 * Space Complexity: O(log10 N)  -- recursion depth
 */
#include <iostream>
using namespace std;

int sumOfDigits(int n) {
    if (n == 0) return 0;
    return (n % 10) + sumOfDigits(n / 10);
}

int main() {
    int n = 92831;
    cout << "Sum of digits of " << n << " = " << sumOfDigits(n) << endl;
    return 0;
}
