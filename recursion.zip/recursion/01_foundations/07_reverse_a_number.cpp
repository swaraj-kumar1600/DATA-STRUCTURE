/*
 * Problem: Reverse a Number Using Recursion
 * ---------------------------------------------
 * Given N, produce the number with its digits reversed.
 *
 * Approach: Maintain an accumulator (passed by reference) that is
 * updated as: acc = acc * 10 + (n % 10), then recurse on n / 10.
 * This is a tail-recursive formulation -- each call carries the
 * partial result forward instead of combining results on the way
 * back up the call stack.
 *
 * Recurrence: T(N) = T(N/10) + O(1)
 * Time Complexity:  O(log10 N)
 * Space Complexity: O(log10 N)  (O(1) if compiler applies TCO)
 */
#include <iostream>
using namespace std;

void reverseNumber(int n, long long &acc) {
    if (n == 0) return;
    acc = acc * 10 + (n % 10);
    reverseNumber(n / 10, acc);
}

int main() {
    int n = 12345;
    long long reversed = 0;
    reverseNumber(n, reversed);
    cout << "Reverse of " << n << " = " << reversed << endl;
    return 0;
}
