/*
 * Problem: Factorial of N
 * ------------------------
 * Compute N! = N * (N-1) * (N-2) * ... * 1, with 0! = 1.
 *
 * Approach (Recursive Decomposition):
 * The problem exhibits optimal substructure: fact(N) = N * fact(N-1).
 * Base case: fact(0) = 1 (identity element for multiplication).
 * Each recursive call reduces the problem size by 1, guaranteeing
 * termination (well-founded recursion on a strictly decreasing
 * non-negative integer).
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)   -- N recursive calls, each O(1) work
 * Space Complexity: O(N)   -- recursion call stack depth
 */
#include <iostream>
using namespace std;

long long factorial(int n) {
    if (n == 0 || n == 1) return 1;      // base case
    return (long long)n * factorial(n - 1); // recursive case
}

int main() {
    int n = 6;
    cout << "Factorial of " << n << " = " << factorial(n) << endl;
    return 0;
}
