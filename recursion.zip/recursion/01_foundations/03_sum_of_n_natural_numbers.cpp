/*
 * Problem: Sum of First N Natural Numbers
 * -----------------------------------------
 * Compute 1 + 2 + 3 + ... + N recursively (without the closed-form
 * N*(N+1)/2, purely as a recursion exercise).
 *
 * Approach: sum(N) = N + sum(N-1), base case sum(0) = 0.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)
 */
#include <iostream>
using namespace std;

int sumN(int n) {
    if (n == 0) return 0;
    return n + sumN(n - 1);
}

int main() {
    int n = 10;
    cout << "Sum of first " << n << " natural numbers = " << sumN(n) << endl;
    return 0;
}
