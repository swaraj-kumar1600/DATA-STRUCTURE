/*
 * Problem: Check if a Number is a Palindrome (Recursively)
 * ---------------------------------------------------------
 * A number is a palindrome if it reads the same forwards and
 * backwards (e.g., 12321).
 *
 * Approach: Reuse the reverse-number recursion to compute the
 * reversed value, then compare against the original. This
 * demonstrates composing smaller recursive subroutines.
 *
 * Time Complexity:  O(log10 N)  -- dominated by the reversal step
 * Space Complexity: O(log10 N)
 */
#include <iostream>
using namespace std;

void reverseNumber(int n, long long &acc) {
    if (n == 0) return;
    acc = acc * 10 + (n % 10);
    reverseNumber(n / 10, acc);
}

bool isPalindrome(int n) {
    long long reversed = 0;
    reverseNumber(n, reversed);
    return reversed == n;
}

int main() {
    int n = 12321;
    cout << n << (isPalindrome(n) ? " is" : " is not") << " a palindrome" << endl;
    return 0;
}
