/*
 * Problem: Compute x^n (Fast Exponentiation)
 * -----------------------------------------------
 * Compute x raised to the power n efficiently.
 *
 * Approach: Naive recursion (x * pow(x, n-1)) is O(N). Instead,
 * exploit the identity:
 *   x^n = (x^(n/2))^2            if n is even
 *   x^n = x * (x^(n/2))^2        if n is odd
 * This halves the problem size each call (divide and conquer),
 * collapsing the recursion depth to logarithmic.
 *
 * Recurrence: T(N) = T(N/2) + O(1)
 * Time Complexity:  O(log N)
 * Space Complexity: O(log N)
 */
#include <iostream>
using namespace std;

double fastPower(double x, long long n) {
    if (n == 0) return 1.0;
    if (n < 0) return 1.0 / fastPower(x, -n);

    double half = fastPower(x, n / 2);
    if (n % 2 == 0) return half * half;
    else return x * half * half;
}

int main() {
    double x = 2.0;
    long long n = 10;
    cout << x << "^" << n << " = " << fastPower(x, n) << endl;
    return 0;
}
