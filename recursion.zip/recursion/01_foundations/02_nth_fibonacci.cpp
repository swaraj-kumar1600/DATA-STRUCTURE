/*
 * Problem: Nth Fibonacci Number
 * ------------------------------
 * F(0)=0, F(1)=1, F(n)=F(n-1)+F(n-2) for n>=2.
 *
 * Approach (Naive Recursion):
 * Directly translate the recurrence into code. Note this creates
 * overlapping subproblems (F(n-2) is recomputed via both branches),
 * making it exponential without memoization.
 *
 * Recurrence: T(N) = T(N-1) + T(N-2) + O(1)
 * Time Complexity:  O(2^N)  -- exponential branching factor ~golden ratio
 * Space Complexity: O(N)    -- max recursion depth
 *
 * Note: Production code should use memoization (top-down DP) or
 * bottom-up tabulation to achieve O(N) time.
 */
#include <iostream>
using namespace std;

int fib(int n) {
    if (n <= 1) return n;               // base cases
    return fib(n - 1) + fib(n - 2);     // combine subproblems
}

int main() {
    int n = 10;
    cout << "Fibonacci(" << n << ") = " << fib(n) << endl;
    return 0;
}
