/*
 * Problem: Count Digits of a Number
 * -------------------------------------
 * Given N, count how many decimal digits it has.
 *
 * Approach: Strip one digit per call via N / 10, incrementing a
 * counter, until N becomes 0.
 *
 * Recurrence: T(N) = T(N/10) + O(1)
 * Time Complexity:  O(log10 N)
 * Space Complexity: O(log10 N)
 */
#include <iostream>
using namespace std;

int countDigits(int n) {
    if (n == 0) return 0;
    return 1 + countDigits(n / 10);
}

int main() {
    int n = 78542;
    cout << "Digit count of " << n << " = " << countDigits(n) << endl;
    return 0;
}
