/*
 * Problem: Diameter of a Binary Tree
 * ----------------------------------------
 * The diameter is the length (edge count) of the longest path
 * between any two nodes, which may or may not pass through the root.
 *
 * Approach: For every node, the longest path THROUGH that node
 * equals leftHeight + rightHeight. Compute this at every node
 * while simultaneously computing heights bottom-up, tracking a
 * running maximum via a reference parameter. This avoids the
 * naive O(N^2) approach of recomputing height separately for
 * every candidate root.
 *
 * Time Complexity:  O(N)  -- height and diameter computed in one pass
 * Space Complexity: O(H)
 */
#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

int diameterHelper(TreeNode* root, int &diameter) {
    if (!root) return 0;
    int leftHeight = diameterHelper(root->left, diameter);
    int rightHeight = diameterHelper(root->right, diameter);
    diameter = max(diameter, leftHeight + rightHeight);
    return 1 + max(leftHeight, rightHeight);
}

int diameter(TreeNode* root) {
    int result = 0;
    diameterHelper(root, result);
    return result;
}

int main() {
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);

    cout << "Diameter = " << diameter(root) << endl;
    return 0;
}
