/*
 * Problem: Path Sum in a Binary Tree
 * -----------------------------------------
 * Determine whether the tree has a root-to-leaf path such that the
 * sum of node values along the path equals a given target.
 *
 * Approach: Subtract the current node's value from the target as we
 * descend, effectively asking each subtree "can you find a path
 * summing to this reduced target?" Base case: a null node can never
 * satisfy a nonzero remaining target. A LEAF node succeeds iff its
 * own value equals the remaining target exactly (target - val == 0).
 *
 * Time Complexity:  O(N)  worst case (every node visited once)
 * Space Complexity: O(H)
 */
#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

bool hasPathSum(TreeNode* root, int target) {
    if (!root) return false;
    if (!root->left && !root->right) return target == root->val; // leaf check
    return hasPathSum(root->left, target - root->val) ||
           hasPathSum(root->right, target - root->val);
}

int main() {
    TreeNode* root = new TreeNode(5);
    root->left = new TreeNode(4);
    root->right = new TreeNode(8);
    root->left->left = new TreeNode(11);
    root->left->left->left = new TreeNode(7);

    int target = 20;
    cout << (hasPathSum(root, target) ? "Path exists" : "No such path") << endl;
    return 0;
}
