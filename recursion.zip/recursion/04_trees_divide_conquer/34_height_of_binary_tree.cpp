/*
 * Problem: Height (Maximum Depth) of a Binary Tree
 * ----------------------------------------------------------
 * Compute the number of nodes along the longest path from the
 * root down to the farthest leaf.
 *
 * Approach: height(root) = 1 + max(height(left), height(right)).
 * Base case: a null node has height 0. This is a bottom-up
 * (postorder-style) computation -- each node's height depends on
 * results returned by its children.
 *
 * Recurrence: T(N) = 2*T(N/2) + O(1)  for a balanced tree
 * Time Complexity:  O(N)
 * Space Complexity: O(H)
 */
#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

int height(TreeNode* root) {
    if (!root) return 0;
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);
    return 1 + max(leftHeight, rightHeight);
}

int main() {
    TreeNode* root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(1);

    cout << "Height = " << height(root) << endl;
    return 0;
}
