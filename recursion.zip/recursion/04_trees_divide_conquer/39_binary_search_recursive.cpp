/*
 * Problem: Binary Search (Recursive)
 * -------------------------------------------
 * Given a sorted array and a target, find the target's index, or
 * -1 if absent.
 *
 * Approach: The canonical Divide-and-Conquer search. Compare the
 * target to the middle element. If equal, done (base case). If the
 * target is smaller, the entire right half can be discarded --
 * recurse only on the left half. If larger, discard the left half
 * and recurse right. Each call halves the search space.
 *
 * Recurrence: T(N) = T(N/2) + O(1)   [Master Theorem case 1]
 * Time Complexity:  O(log N)
 * Space Complexity: O(log N)  -- recursion stack (O(1) if converted
 *                                to an iterative loop)
 */
#include <iostream>
#include <vector>
using namespace std;

int binarySearch(vector<int>& arr, int left, int right, int target) {
    if (left > right) return -1;             // base case: not found
    int mid = left + (right - left) / 2;
    if (arr[mid] == target) return mid;      // base case: found
    if (arr[mid] > target)
        return binarySearch(arr, left, mid - 1, target);  // search left half
    else
        return binarySearch(arr, mid + 1, right, target); // search right half
}

int main() {
    vector<int> arr = {1, 3, 5, 7, 9, 11, 13};
    int target = 7;
    cout << "Index of " << target << " = "
         << binarySearch(arr, 0, arr.size() - 1, target) << endl;
    return 0;
}
