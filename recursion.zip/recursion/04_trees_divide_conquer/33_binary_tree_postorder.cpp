/*
 * Problem: Binary Tree Postorder Traversal
 * ------------------------------------------------
 * Visit nodes in Left -> Right -> Root order. Useful for safely
 * deleting a tree (children freed before their parent) or
 * evaluating expression trees.
 *
 * Approach: Recurse into both children first, then process the
 * root last -- the defining characteristic of postorder.
 *
 * Time Complexity:  O(N)
 * Space Complexity: O(H)
 */
#include <iostream>
#include <vector>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

void postorder(TreeNode* root, vector<int>& result) {
    if (!root) return;
    postorder(root->left, result);
    postorder(root->right, result);
    result.push_back(root->val);
}

int main() {
    TreeNode* root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);

    vector<int> result;
    postorder(root, result);
    for (int x : result) cout << x << " ";
    cout << endl;
    return 0;
}
