/*
 * Problem: Binary Tree Inorder Traversal
 * ----------------------------------------------
 * Visit nodes in Left -> Root -> Right order, which for a Binary
 * Search Tree yields values in sorted ascending order.
 *
 * Approach: Recursion mirrors the tree's own recursive definition
 * (a tree is a root plus two subtrees). Recurse left, visit root,
 * recurse right. Base case: a null node contributes nothing.
 *
 * Time Complexity:  O(N)  -- every node visited exactly once
 * Space Complexity: O(H)  -- H = tree height (recursion stack);
 *                             O(N) worst case for a skewed tree
 */
#include <iostream>
#include <vector>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

void inorder(TreeNode* root, vector<int>& result) {
    if (!root) return;
    inorder(root->left, result);
    result.push_back(root->val);
    inorder(root->right, result);
}

int main() {
    TreeNode* root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);

    vector<int> result;
    inorder(root, result);
    for (int x : result) cout << x << " ";
    cout << endl;
    return 0;
}
