/*
 * Problem: Tower of Hanoi
 * ---------------------------------
 * Move N disks from a source rod to a destination rod, using an
 * auxiliary rod, obeying two rules: only one disk may be moved at
 * a time, and a larger disk may never be placed on a smaller one.
 *
 * Approach (the archetypal recursion problem): to move N disks
 * from source to destination:
 *   1. Move the top N-1 disks from source to auxiliary (using
 *      destination as the temporary helper for that sub-move).
 *   2. Move the single remaining largest disk from source directly
 *      to destination.
 *   3. Move the N-1 disks from auxiliary to destination (using
 *      source as the temporary helper).
 * Base case: moving 0 disks requires no action.
 * This demonstrates recursion where the roles of the three rods
 * ROTATE with each recursive call -- a key insight for the problem.
 *
 * Recurrence: T(N) = 2*T(N-1) + O(1)
 * Time Complexity:  O(2^N)   -- and this is proven OPTIMAL; 2^N - 1
 *                    moves are mathematically necessary
 * Space Complexity: O(N)     -- recursion depth
 */
#include <iostream>
using namespace std;

void towerOfHanoi(int n, char source, char auxiliary, char destination, int &moveCount) {
    if (n == 0) return;
    towerOfHanoi(n - 1, source, destination, auxiliary, moveCount);
    moveCount++;
    cout << "Move disk " << n << " from " << source << " to " << destination << endl;
    towerOfHanoi(n - 1, auxiliary, source, destination, moveCount);
}

int main() {
    int n = 3;
    int moveCount = 0;
    towerOfHanoi(n, 'A', 'B', 'C', moveCount);
    cout << "Total moves: " << moveCount << " (minimum possible: " << (1 << n) - 1 << ")" << endl;
    return 0;
}
