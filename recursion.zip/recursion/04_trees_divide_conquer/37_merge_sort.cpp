/*
 * Problem: Merge Sort
 * ---------------------------
 * Sort an array using the classic Divide-and-Conquer paradigm.
 *
 * Approach: DIVIDE the array into two halves at the midpoint.
 * CONQUER by recursively sorting each half. COMBINE by merging the
 * two now-sorted halves into a single sorted sequence using a
 * two-pointer merge. Base case: a subarray of size <= 1 is already
 * sorted.
 *
 * Recurrence: T(N) = 2*T(N/2) + O(N)   [Master Theorem case 2]
 * Time Complexity:  O(N log N)  -- guaranteed, regardless of input order
 * Space Complexity: O(N)        -- auxiliary array for merging
 */
#include <iostream>
#include <vector>
using namespace std;

void merge(vector<int>& arr, int left, int mid, int right) {
    vector<int> temp;
    int i = left, j = mid + 1;
    while (i <= mid && j <= right) {
        if (arr[i] <= arr[j]) temp.push_back(arr[i++]);
        else temp.push_back(arr[j++]);
    }
    while (i <= mid) temp.push_back(arr[i++]);
    while (j <= right) temp.push_back(arr[j++]);
    for (int k = left; k <= right; k++) arr[k] = temp[k - left];
}

void mergeSort(vector<int>& arr, int left, int right) {
    if (left >= right) return;         // base case: 0 or 1 elements
    int mid = left + (right - left) / 2;
    mergeSort(arr, left, mid);          // conquer left half
    mergeSort(arr, mid + 1, right);     // conquer right half
    merge(arr, left, mid, right);       // combine
}

int main() {
    vector<int> arr = {5, 2, 9, 1, 5, 6};
    mergeSort(arr, 0, arr.size() - 1);
    for (int x : arr) cout << x << " ";
    cout << endl;
    return 0;
}
