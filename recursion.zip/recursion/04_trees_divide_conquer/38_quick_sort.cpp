/*
 * Problem: Quick Sort
 * ---------------------------
 * Another Divide-and-Conquer sorting algorithm, distinguished from
 * merge sort by doing the "hard work" during the divide/partition
 * step rather than the combine step.
 *
 * Approach: Choose a pivot (last element here). PARTITION the array
 * so all elements <= pivot land to its left and all elements >
 * pivot land to its right, placing the pivot at its final sorted
 * index. Recursively sort the left and right partitions
 * independently. Because partitioning places the pivot correctly,
 * no combine/merge step is needed afterward.
 *
 * Recurrence: T(N) = T(k) + T(N-k-1) + O(N)
 * Time Complexity:  O(N log N) average, O(N^2) worst case (already
 *                    sorted input with a poor pivot choice)
 * Space Complexity: O(log N) average recursion depth (in-place)
 */
#include <iostream>
#include <vector>
using namespace std;

int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;  // pivot's final sorted position
}

void quickSort(vector<int>& arr, int low, int high) {
    if (low >= high) return;           // base case
    int pivotIdx = partition(arr, low, high);
    quickSort(arr, low, pivotIdx - 1);  // conquer left partition
    quickSort(arr, pivotIdx + 1, high); // conquer right partition
}

int main() {
    vector<int> arr = {10, 7, 8, 9, 1, 5};
    quickSort(arr, 0, arr.size() - 1);
    for (int x : arr) cout << x << " ";
    cout << endl;
    return 0;
}
