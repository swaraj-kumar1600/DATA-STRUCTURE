/*
 * Problem: Binary Tree Preorder Traversal
 * -----------------------------------------------
 * Visit nodes in Root -> Left -> Right order. Useful for creating
 * a copy of the tree or serializing its structure.
 *
 * Approach: Identical recursive skeleton to inorder, but the root
 * is processed before descending into either subtree.
 *
 * Time Complexity:  O(N)
 * Space Complexity: O(H)
 */
#include <iostream>
#include <vector>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v) : val(v), left(nullptr), right(nullptr) {}
};

void preorder(TreeNode* root, vector<int>& result) {
    if (!root) return;
    result.push_back(root->val);
    preorder(root->left, result);
    preorder(root->right, result);
}

int main() {
    TreeNode* root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);

    vector<int> result;
    preorder(root, result);
    for (int x : result) cout << x << " ";
    cout << endl;
    return 0;
}
