/*
 * Problem: Check if an Array is Sorted (Non-Decreasing)
 * ------------------------------------------------------------
 * Determine whether arr[0] <= arr[1] <= ... <= arr[n-1].
 *
 * Approach: The array is sorted iff arr[idx] <= arr[idx+1] AND the
 * remaining suffix starting at idx+1 is sorted. This is a boolean
 * AND-combination of a local check with a recursive subproblem.
 * Base case: a range of size 0 or 1 is trivially sorted.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
using namespace std;

bool isSorted(vector<int>& arr, int idx) {
    if (idx >= (int)arr.size() - 1) return true;
    if (arr[idx] > arr[idx + 1]) return false;
    return isSorted(arr, idx + 1);
}

int main() {
    vector<int> arr = {1, 2, 3, 4, 5};
    cout << (isSorted(arr, 0) ? "Sorted" : "Not sorted") << endl;
    return 0;
}
