/*
 * Problem: Linear Search Using Recursion
 * --------------------------------------------
 * Find the index of a target value in an unsorted array, or -1 if
 * absent.
 *
 * Approach: Check arr[idx] against target; if it matches, return
 * idx (base case: found). If idx reaches array length, return -1
 * (base case: exhausted). Otherwise recurse on idx+1.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N) worst case
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
using namespace std;

int linearSearch(vector<int>& arr, int idx, int target) {
    if (idx == (int)arr.size()) return -1;
    if (arr[idx] == target) return idx;
    return linearSearch(arr, idx + 1, target);
}

int main() {
    vector<int> arr = {4, 2, 7, 1, 9};
    int target = 7;
    cout << "Index of " << target << " = " << linearSearch(arr, 0, target) << endl;
    return 0;
}
