/*
 * Problem: Reverse a String Using Recursion
 * -----------------------------------------------
 * Given a string, reverse it in place using recursion (no loops).
 *
 * Approach: Use a two-pointer technique driven by recursion --
 * swap characters at the left and right boundaries, then recurse
 * on the shrunken inner range [left+1, right-1]. This converges
 * when left >= right.
 *
 * Recurrence: T(N) = T(N-2) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)  -- recursion stack (O(1) auxiliary otherwise)
 */
#include <iostream>
#include <string>
using namespace std;

void reverseString(string &s, int left, int right) {
    if (left >= right) return;
    swap(s[left], s[right]);
    reverseString(s, left + 1, right - 1);
}

int main() {
    string s = "recursion";
    reverseString(s, 0, s.size() - 1);
    cout << "Reversed: " << s << endl;
    return 0;
}
