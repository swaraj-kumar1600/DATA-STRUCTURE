/*
 * Problem: Check if a String is a Palindrome
 * ------------------------------------------------
 * Determine whether a string reads the same forwards and backwards.
 *
 * Approach: Compare the outermost characters; if they mismatch,
 * short-circuit to false. Otherwise recurse inward on the substring
 * excluding both ends. Base case: left >= right (0 or 1 characters
 * remain, trivially a palindrome).
 *
 * Recurrence: T(N) = T(N-2) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)
 */
#include <iostream>
#include <string>
using namespace std;

bool isPalindrome(const string &s, int left, int right) {
    if (left >= right) return true;
    if (s[left] != s[right]) return false;
    return isPalindrome(s, left + 1, right - 1);
}

int main() {
    string s = "madam";
    cout << s << (isPalindrome(s, 0, s.size() - 1) ? " is" : " is not")
         << " a palindrome" << endl;
    return 0;
}
