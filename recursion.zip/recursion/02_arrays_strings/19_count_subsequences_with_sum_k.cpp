/*
 * Problem: Count Subsequences of an Array with Sum K
 * -----------------------------------------------------------
 * Given an array of integers and a target K, count how many
 * subsequences sum to exactly K.
 *
 * Approach: Extend the include/exclude template with a running
 * sum parameter. At each index, branch into "include arr[idx] in
 * the sum" and "exclude it". A base case at idx == n checks
 * whether the accumulated sum equals K, contributing 1 or 0 to
 * the count.
 *
 * Recurrence: T(N) = 2*T(N-1) + O(1)
 * Time Complexity:  O(2^N)  -- exponential without memoization
 * Space Complexity: O(N)
 *
 * Note: This is a classic candidate for memoization on (idx,
 * remainingSum) to bring it down to pseudo-polynomial O(N*K).
 */
#include <iostream>
#include <vector>
using namespace std;

int countSubsequences(vector<int>& arr, int idx, int currentSum, int k) {
    if (idx == (int)arr.size()) {
        return currentSum == k ? 1 : 0;
    }
    int include = countSubsequences(arr, idx + 1, currentSum + arr[idx], k);
    int exclude = countSubsequences(arr, idx + 1, currentSum, k);
    return include + exclude;
}

int main() {
    vector<int> arr = {1, 2, 3, 1};
    int k = 3;
    cout << "Count of subsequences with sum " << k << " = "
         << countSubsequences(arr, 0, 0, k) << endl;
    return 0;
}
