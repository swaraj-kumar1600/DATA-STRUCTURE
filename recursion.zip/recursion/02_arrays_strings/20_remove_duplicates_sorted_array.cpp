/*
 * Problem: Remove Duplicates from a Sorted Array (Recursively)
 * ---------------------------------------------------------------------
 * Given a sorted array, build a new array containing only the
 * distinct elements, preserving order.
 *
 * Approach: Because the array is sorted, duplicates are always
 * adjacent. At each index, compare arr[idx] to the next element;
 * if they differ, keep arr[idx] and recurse on idx+1. If they
 * match, skip idx entirely (do not add to the result) and recurse
 * on idx+1. This is a filter-style recursion.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)  -- recursion stack + output array
 */
#include <iostream>
#include <vector>
using namespace std;

void removeDuplicates(vector<int>& arr, int idx, vector<int>& result) {
    if (idx == (int)arr.size()) return;
    if (idx == (int)arr.size() - 1 || arr[idx] != arr[idx + 1]) {
        result.push_back(arr[idx]);
    }
    removeDuplicates(arr, idx + 1, result);
}

int main() {
    vector<int> arr = {1, 1, 2, 2, 2, 3, 4, 4};
    vector<int> result;
    removeDuplicates(arr, 0, result);
    cout << "Distinct elements: ";
    for (int x : result) cout << x << " ";
    cout << endl;
    return 0;
}
