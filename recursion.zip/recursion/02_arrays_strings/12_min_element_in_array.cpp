/*
 * Problem: Find Minimum Element in an Array
 * ---------------------------------------------
 * Mirror of the maximum-element problem, using min instead of max
 * as the combining operator.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
using namespace std;

int findMin(vector<int>& arr, int idx) {
    if (idx == arr.size() - 1) return arr[idx];
    int minOfRest = findMin(arr, idx + 1);
    return min(arr[idx], minOfRest);
}

int main() {
    vector<int> arr = {3, 7, 1, 9, 4};
    cout << "Min element = " << findMin(arr, 0) << endl;
    return 0;
}
