/*
 * Problem: Print All Subsequences of a String
 * ---------------------------------------------------
 * A subsequence is any selection of characters that preserves
 * relative order (contiguity not required). Print every possible
 * subsequence, including the empty one.
 *
 * Approach (Include/Exclude Recursion -- the canonical backtracking
 * template): at each index, branch into two recursive calls --
 * one that includes the current character in the running subset,
 * and one that excludes it. This explores the full binary decision
 * tree of depth N, yielding 2^N leaves (subsequences).
 *
 * Recurrence: T(N) = 2*T(N-1) + O(1)
 * Time Complexity:  O(2^N)      -- 2^N subsequences generated
 * Space Complexity: O(N)        -- recursion depth (excluding output)
 */
#include <iostream>
#include <string>
using namespace std;

void printSubsequences(const string &s, int idx, string current) {
    if (idx == (int)s.size()) {
        cout << (current.empty() ? "<empty>" : current) << endl;
        return;
    }
    // Include current character
    printSubsequences(s, idx + 1, current + s[idx]);
    // Exclude current character
    printSubsequences(s, idx + 1, current);
}

int main() {
    string s = "abc";
    printSubsequences(s, 0, "");
    return 0;
}
