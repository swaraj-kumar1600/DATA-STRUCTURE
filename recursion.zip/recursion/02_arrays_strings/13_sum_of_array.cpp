/*
 * Problem: Sum of Array Elements
 * ------------------------------------
 * Compute the sum of all elements using recursion.
 *
 * Approach: sum(arr, idx) = arr[idx] + sum(arr, idx+1), with the
 * base case being an empty remaining range returning 0.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
using namespace std;

int sumArray(vector<int>& arr, int idx) {
    if (idx == arr.size()) return 0;
    return arr[idx] + sumArray(arr, idx + 1);
}

int main() {
    vector<int> arr = {1, 2, 3, 4, 5};
    cout << "Sum = " << sumArray(arr, 0) << endl;
    return 0;
}
