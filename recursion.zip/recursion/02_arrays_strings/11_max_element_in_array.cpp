/*
 * Problem: Find Maximum Element in an Array
 * ---------------------------------------------
 * Given an array, find its maximum element using recursion instead
 * of an iterative loop.
 *
 * Approach: max(arr[0..n-1]) = max(arr[0], max(arr[1..n-1])).
 * Base case: a single-element subarray's max is itself.
 *
 * Recurrence: T(N) = T(N-1) + O(1)
 * Time Complexity:  O(N)
 * Space Complexity: O(N)  -- recursion stack
 */
#include <iostream>
#include <vector>
using namespace std;

int findMax(vector<int>& arr, int idx) {
    if (idx == arr.size() - 1) return arr[idx];
    int maxOfRest = findMax(arr, idx + 1);
    return max(arr[idx], maxOfRest);
}

int main() {
    vector<int> arr = {3, 7, 1, 9, 4};
    cout << "Max element = " << findMax(arr, 0) << endl;
    return 0;
}
