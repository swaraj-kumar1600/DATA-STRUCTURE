/*
 * Problem: Combination Sum
 * --------------------------------
 * Given a set of distinct positive candidates and a target, find
 * all unique combinations where the chosen numbers sum to target.
 * The same candidate may be reused an unlimited number of times.
 *
 * Approach: Standard backtracking with an index parameter that does
 * NOT necessarily advance on recursive calls where we reuse the
 * current candidate -- this is what permits unlimited reuse of a
 * single element while still avoiding permutation-style duplicates
 * (we never look backward, only forward or stay put).
 * Prune branches early when the running sum exceeds target.
 *
 * Time Complexity:  O(2^target) worst case (search-tree dependent)
 * Space Complexity: O(target / min(candidates))  -- max recursion depth
 */
#include <iostream>
#include <vector>
using namespace std;

void combinationSum(vector<int>& candidates, int idx, int remaining,
                     vector<int>& current, vector<vector<int>>& result) {
    if (remaining == 0) {
        result.push_back(current);
        return;
    }
    if (idx == (int)candidates.size() || remaining < 0) return;

    // Include candidates[idx] again (unlimited reuse)
    current.push_back(candidates[idx]);
    combinationSum(candidates, idx, remaining - candidates[idx], current, result);
    current.pop_back();  // backtrack

    // Move on without using candidates[idx] again
    combinationSum(candidates, idx + 1, remaining, current, result);
}

int main() {
    vector<int> candidates = {2, 3, 6, 7};
    int target = 7;
    vector<int> current;
    vector<vector<int>> result;
    combinationSum(candidates, 0, target, current, result);
    for (auto &comb : result) {
        for (int x : comb) cout << x << " ";
        cout << endl;
    }
    return 0;
}
