/*
 * Problem: Print All Subsets (Power Set) of an Array
 * -----------------------------------------------------------
 * Given a set of distinct integers, generate its power set (all
 * 2^N possible subsets, including the empty set and the full set).
 *
 * Approach: Same include/exclude decision tree used for string
 * subsequences, generalized to arrays. At each index we decide
 * whether the current element belongs to the subset being built.
 *
 * Recurrence: T(N) = 2*T(N-1) + O(1)
 * Time Complexity:  O(2^N * N)  -- 2^N subsets, O(N) to copy/print each
 * Space Complexity: O(N)        -- recursion depth + current subset
 */
#include <iostream>
#include <vector>
using namespace std;

void printSubsets(vector<int>& nums, int idx, vector<int>& current) {
    if (idx == (int)nums.size()) {
        cout << "{ ";
        for (int x : current) cout << x << " ";
        cout << "}" << endl;
        return;
    }
    current.push_back(nums[idx]);       // include
    printSubsets(nums, idx + 1, current);
    current.pop_back();                 // backtrack
    printSubsets(nums, idx + 1, current); // exclude
}

int main() {
    vector<int> nums = {1, 2, 3};
    vector<int> current;
    printSubsets(nums, 0, current);
    return 0;
}
