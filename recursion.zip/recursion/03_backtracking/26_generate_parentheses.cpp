/*
 * Problem: Generate Valid Parentheses
 * -----------------------------------------
 * Given N pairs of parentheses, generate all combinations of
 * well-formed (balanced) parenthesis strings.
 *
 * Approach: Track two counters -- open (parens placed) and close
 * (parens closed) -- as recursion parameters, constrained by two
 * invariants that prune invalid branches immediately:
 *   1. open < N        -> allowed to place an opening bracket "("
 *   2. close < open     -> allowed to place a closing bracket ")"
 *                           (never exceed the number of opens so far)
 * Base case: a string of length 2N with open == close == N.
 *
 * Time Complexity:  O(4^N / sqrt(N))  -- bounded by the Nth Catalan number
 * Space Complexity: O(N)  -- recursion depth (2N max)
 */
#include <iostream>
#include <string>
using namespace std;

void generateParens(int n, int open, int close, string current) {
    if ((int)current.size() == 2 * n) {
        cout << current << endl;
        return;
    }
    if (open < n) generateParens(n, open + 1, close, current + "(");
    if (close < open) generateParens(n, open, close + 1, current + ")");
}

int main() {
    int n = 3;
    generateParens(n, 0, 0, "");
    return 0;
}
