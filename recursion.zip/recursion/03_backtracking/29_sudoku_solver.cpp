/*
 * Problem: Sudoku Solver
 * ------------------------------
 * Given a partially filled 9x9 Sudoku board, fill it so that every
 * row, column, and 3x3 sub-box contains digits 1-9 exactly once.
 *
 * Approach: Scan for the next empty cell ('.'). Try digits 1-9 in
 * that cell; before committing, isValid() checks the row, column,
 * and 3x3 box constraints in O(9) time. If valid, place the digit
 * and recurse to solve the rest of the board. If the recursive call
 * succeeds, propagate success upward immediately. If it fails,
 * backtrack: reset the cell to empty and try the next digit. Base
 * case: no empty cell remains, meaning the board is fully solved.
 *
 * Time Complexity:  O(9^(number of empty cells)) worst case
 * Space Complexity: O(1) extra (in-place), O(81) recursion depth max
 */
#include <iostream>
#include <vector>
using namespace std;

bool isValid(vector<vector<char>>& board, int row, int col, char digit) {
    for (int i = 0; i < 9; i++) {
        if (board[row][i] == digit) return false;               // row check
        if (board[i][col] == digit) return false;                // column check
        int boxRow = 3 * (row / 3) + i / 3;
        int boxCol = 3 * (col / 3) + i % 3;
        if (board[boxRow][boxCol] == digit) return false;         // box check
    }
    return true;
}

bool solveSudoku(vector<vector<char>>& board) {
    for (int row = 0; row < 9; row++) {
        for (int col = 0; col < 9; col++) {
            if (board[row][col] != '.') continue;
            for (char digit = '1'; digit <= '9'; digit++) {
                if (isValid(board, row, col, digit)) {
                    board[row][col] = digit;                       // place
                    if (solveSudoku(board)) return true;
                    board[row][col] = '.';                       // backtrack
                }
            }
            return false; // no digit worked for this empty cell
        }
    }
    return true; // no empty cells left -> solved
}

int main() {
    vector<vector<char>> board = {
        {'5','3','.','.','7','.','.','.','.'},
        {'6','.','.','1','9','5','.','.','.'},
        {'.','9','8','.','.','.','.','6','.'},
        {'8','.','.','.','6','.','.','.','3'},
        {'4','.','.','8','.','3','.','.','1'},
        {'7','.','.','.','2','.','.','.','6'},
        {'.','6','.','.','.','.','2','8','.'},
        {'.','.','.','4','1','9','.','.','5'},
        {'.','.','.','.','8','.','.','7','9'}
    };
    if (solveSudoku(board)) {
        for (auto &row : board) {
            for (char c : row) cout << c << " ";
            cout << endl;
        }
    } else {
        cout << "No solution exists" << endl;
    }
    return 0;
}
