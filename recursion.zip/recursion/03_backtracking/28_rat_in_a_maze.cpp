/*
 * Problem: Rat in a Maze
 * ------------------------------
 * Given an N x N maze with cells marked 1 (open) or 0 (blocked),
 * find all paths from the top-left cell (0,0) to the bottom-right
 * cell (N-1,N-1). The rat may move Down, Left, Right, Up (order
 * defined below) but cannot revisit a cell or step on a blocked one.
 *
 * Approach: At each cell, try each of the four directions in turn.
 * Before moving, verify the destination is within bounds, open, and
 * not already visited. Mark the current cell visited, append the
 * move to the path, recurse, then backtrack: unmark the cell and
 * remove the move -- this is essential so the cell can be reused on
 * a different path branch.
 *
 * Time Complexity:  O(4^(N^2)) worst case (heavily pruned by walls/visited)
 * Space Complexity: O(N^2)  -- visited matrix + recursion depth
 */
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int dr[] = {1, 0, 0, -1};      // Down, Left, Right, Up
int dc[] = {0, -1, 1, 0};
char dirChar[] = {'D', 'L', 'R', 'U'};

void findPaths(vector<vector<int>>& maze, int r, int c, int n,
               vector<vector<bool>>& visited, string path,
               vector<string>& result) {
    if (r == n - 1 && c == n - 1) {
        result.push_back(path);
        return;
    }
    visited[r][c] = true;
    for (int dir = 0; dir < 4; dir++) {
        int nr = r + dr[dir], nc = c + dc[dir];
        if (nr >= 0 && nr < n && nc >= 0 && nc < n &&
            maze[nr][nc] == 1 && !visited[nr][nc]) {
            findPaths(maze, nr, nc, n, visited, path + dirChar[dir], result);
        }
    }
    visited[r][c] = false;  // backtrack
}

int main() {
    vector<vector<int>> maze = {
        {1, 0, 0, 0},
        {1, 1, 0, 1},
        {1, 1, 0, 0},
        {0, 1, 1, 1}
    };
    int n = maze.size();
    vector<vector<bool>> visited(n, vector<bool>(n, false));
    vector<string> result;
    if (maze[0][0] == 1) findPaths(maze, 0, 0, n, visited, "", result);
    for (auto &p : result) cout << p << endl;
    return 0;
}
