/*
 * Problem: Permutations of an Array With Duplicates (Unique Only)
 * --------------------------------------------------------------------------
 * Given an array that may contain duplicate values, print all
 * *distinct* permutations (no repeated arrangement should appear).
 *
 * Approach: Use a used[] boolean array plus the choose-explore-
 * unchoose backtracking template. Sort the input first so that
 * duplicate values become adjacent. At each recursive level, skip
 * a candidate value if it equals the previous candidate at the
 * same level AND the previous one has not been used yet -- this
 * pruning rule ("skip same-level duplicates") is the standard
 * technique to avoid generating the same permutation twice.
 *
 * Time Complexity:  O(N! * N) worst case (fewer with duplicates due to pruning)
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void permuteUnique(vector<int>& nums, vector<int>& current,
                    vector<bool>& used, vector<vector<int>>& result) {
    if (current.size() == nums.size()) {
        result.push_back(current);
        return;
    }
    for (int i = 0; i < (int)nums.size(); i++) {
        if (used[i]) continue;
        if (i > 0 && nums[i] == nums[i - 1] && !used[i - 1]) continue; // prune
        used[i] = true;
        current.push_back(nums[i]);
        permuteUnique(nums, current, used, result);
        current.pop_back();  // backtrack
        used[i] = false;
    }
}

int main() {
    vector<int> nums = {1, 1, 2};
    sort(nums.begin(), nums.end());
    vector<int> current;
    vector<bool> used(nums.size(), false);
    vector<vector<int>> result;
    permuteUnique(nums, current, used, result);
    for (auto &perm : result) {
        for (int x : perm) cout << x << " ";
        cout << endl;
    }
    return 0;
}
