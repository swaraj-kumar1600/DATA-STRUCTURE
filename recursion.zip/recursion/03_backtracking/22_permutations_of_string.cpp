/*
 * Problem: Print All Permutations of a String
 * ---------------------------------------------------
 * Given a string of distinct characters, print every arrangement
 * (permutation) of its characters.
 *
 * Approach (Position-Swapping Backtracking): fix each index in
 * turn by swapping in every unused character from the remaining
 * suffix, recurse to fix the next position, then undo the swap
 * (backtrack) to restore the original order for the next branch.
 * Base case: when idx reaches the string length, the fully fixed
 * arrangement is a complete permutation.
 *
 * Recurrence: T(N) = N * T(N-1) + O(1)
 * Time Complexity:  O(N! * N)  -- N! permutations, O(N) each to print
 * Space Complexity: O(N)       -- recursion depth
 */
#include <iostream>
#include <string>
using namespace std;

void permute(string &s, int idx) {
    if (idx == (int)s.size()) {
        cout << s << endl;
        return;
    }
    for (int i = idx; i < (int)s.size(); i++) {
        swap(s[idx], s[i]);      // choose
        permute(s, idx + 1);     // explore
        swap(s[idx], s[i]);      // un-choose (backtrack)
    }
}

int main() {
    string s = "abc";
    permute(s, 0);
    return 0;
}
