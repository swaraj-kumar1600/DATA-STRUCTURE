/*
 * Problem: Word Search in a Grid
 * --------------------------------------
 * Given a 2D grid of characters and a word, determine if the word
 * can be constructed from letters of sequentially adjacent cells
 * (horizontally or vertically), using each cell at most once.
 *
 * Approach: Try every cell as a potential starting point for the
 * first character. From a matching cell, explore all four
 * directions, requiring the next cell to match the next character
 * in the word. Mark cells visited by temporarily overwriting them
 * (a common space-saving trick to avoid a separate visited matrix),
 * then restore the original character on backtrack.
 *
 * Time Complexity:  O(rows * cols * 4^L)  -- L = word length
 * Space Complexity: O(L)  -- recursion depth
 */
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int dr[] = {1, -1, 0, 0};
int dc[] = {0, 0, 1, -1};

bool dfs(vector<vector<char>>& grid, string &word, int idx, int r, int c) {
    if (idx == (int)word.size()) return true;
    if (r < 0 || r >= (int)grid.size() || c < 0 || c >= (int)grid[0].size())
        return false;
    if (grid[r][c] != word[idx]) return false;

    char temp = grid[r][c];
    grid[r][c] = '#';  // mark visited

    for (int dir = 0; dir < 4; dir++) {
        if (dfs(grid, word, idx + 1, r + dr[dir], c + dc[dir])) {
            grid[r][c] = temp;  // restore before returning
            return true;
        }
    }
    grid[r][c] = temp;  // backtrack
    return false;
}

bool exist(vector<vector<char>>& grid, string word) {
    for (int r = 0; r < (int)grid.size(); r++)
        for (int c = 0; c < (int)grid[0].size(); c++)
            if (dfs(grid, word, 0, r, c)) return true;
    return false;
}

int main() {
    vector<vector<char>> grid = {
        {'A','B','C','E'},
        {'S','F','C','S'},
        {'A','D','E','E'}
    };
    string word = "ABCCED";
    cout << (exist(grid, word) ? "Found" : "Not found") << endl;
    return 0;
}
