/*
 * Problem: Combination Sum II
 * -----------------------------------
 * Given a collection of candidates that MAY contain duplicates and
 * a target, find all unique combinations where the numbers sum to
 * target. Each candidate may be used at most ONCE per combination.
 *
 * Approach: Sort the input so duplicates are adjacent. Use a for-
 * loop based backtracking template (rather than the binary include/
 * exclude form) so that at each recursion level we can explicitly
 * skip over duplicate siblings: "if (i > idx && candidates[i] ==
 * candidates[i-1]) continue;" This prevents generating the same
 * combination multiple times while still allowing a duplicate value
 * to appear once within a single combination (via deeper recursion).
 *
 * Time Complexity:  O(2^N) worst case
 * Space Complexity: O(N)
 */
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void combinationSum2(vector<int>& candidates, int idx, int remaining,
                      vector<int>& current, vector<vector<int>>& result) {
    if (remaining == 0) {
        result.push_back(current);
        return;
    }
    for (int i = idx; i < (int)candidates.size(); i++) {
        if (candidates[i] > remaining) break;              // prune (sorted)
        if (i > idx && candidates[i] == candidates[i - 1]) continue; // skip dup
        current.push_back(candidates[i]);
        combinationSum2(candidates, i + 1, remaining - candidates[i], current, result);
        current.pop_back();  // backtrack
    }
}

int main() {
    vector<int> candidates = {10, 1, 2, 7, 6, 1, 5};
    sort(candidates.begin(), candidates.end());
    int target = 8;
    vector<int> current;
    vector<vector<int>> result;
    combinationSum2(candidates, 0, target, current, result);
    for (auto &comb : result) {
        for (int x : comb) cout << x << " ";
        cout << endl;
    }
    return 0;
}
