/*
 * Problem: N-Queens
 * -------------------------
 * Place N queens on an N x N chessboard such that no two queens
 * attack each other (no shared row, column, or diagonal). Print
 * all valid board configurations.
 *
 * Approach: Place queens one row at a time (this guarantees no
 * row conflicts by construction). For each row, try every column;
 * before committing, run isSafe() to check the column and both
 * diagonals against all previously placed queens. If safe, place
 * the queen, recurse to the next row, then backtrack (remove the
 * queen) to try the next column. Base case: row == N means all
 * queens are placed validly.
 *
 * Time Complexity:  O(N!) worst case (heavily pruned in practice)
 * Space Complexity: O(N^2)  -- board storage
 */
#include <iostream>
#include <vector>
using namespace std;

bool isSafe(vector<string>& board, int row, int col, int n) {
    // Check column above
    for (int i = 0; i < row; i++)
        if (board[i][col] == 'Q') return false;
    // Check upper-left diagonal
    for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
        if (board[i][j] == 'Q') return false;
    // Check upper-right diagonal
    for (int i = row - 1, j = col + 1; i >= 0 && j < n; i--, j++)
        if (board[i][j] == 'Q') return false;
    return true;
}

void solveNQueens(vector<string>& board, int row, int n, int &count) {
    if (row == n) {
        count++;
        for (auto &r : board) cout << r << endl;
        cout << "---" << endl;
        return;
    }
    for (int col = 0; col < n; col++) {
        if (isSafe(board, row, col, n)) {
            board[row][col] = 'Q';                 // place
            solveNQueens(board, row + 1, n, count);
            board[row][col] = '.';                 // backtrack
        }
    }
}

int main() {
    int n = 4;
    vector<string> board(n, string(n, '.'));
    int count = 0;
    solveNQueens(board, 0, n, count);
    cout << "Total solutions: " << count << endl;
    return 0;
}
