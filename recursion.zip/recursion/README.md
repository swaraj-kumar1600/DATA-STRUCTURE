# Recursion — 40 Problems with Detailed Explanations

A structured collection of 40 classic recursion problems in C++, organized by
increasing conceptual complexity. Every file contains:
- The problem statement
- The recursive approach / intuition
- The recurrence relation (where applicable)
- Time and space complexity analysis
- A working, compilable `main()` with a sample input

## Folder structure

### `01_foundations/` — Core recursive mechanics (10 problems)
| # | File | Concept |
|---|------|---------|
| 1 | factorial.cpp | Basic linear recursion |
| 2 | nth_fibonacci.cpp | Overlapping subproblems / branching recursion |
| 3 | sum_of_n_natural_numbers.cpp | Accumulation via recursion |
| 4 | sum_of_digits.cpp | Recursion on shrinking numeric input |
| 5 | product_of_digits.cpp | Recursion with multiplicative identity |
| 6 | count_digits.cpp | Counting via recursion |
| 7 | reverse_a_number.cpp | Tail recursion with accumulator |
| 8 | check_palindrome_number.cpp | Composing recursive subroutines |
| 9 | gcd_euclidean.cpp | Euclidean algorithm |
| 10 | power_fast_exponentiation.cpp | Divide and conquer (logarithmic recursion) |

### `02_arrays_strings/` — Recursion over linear structures (10 problems)
| # | File | Concept |
|---|------|---------|
| 11 | max_element_in_array.cpp | Recursive reduction |
| 12 | min_element_in_array.cpp | Recursive reduction |
| 13 | sum_of_array.cpp | Recursive accumulation |
| 14 | check_array_sorted.cpp | Boolean AND-combination recursion |
| 15 | linear_search_recursive.cpp | Search via recursion |
| 16 | reverse_a_string.cpp | Two-pointer recursion |
| 17 | check_palindrome_string.cpp | Two-pointer recursion |
| 18 | print_all_subsequences.cpp | Include/exclude template (2^N) |
| 19 | count_subsequences_with_sum_k.cpp | Include/exclude with target sum |
| 20 | remove_duplicates_sorted_array.cpp | Filter-style recursion |

### `03_backtracking/` — Explore, prune, undo (10 problems)
| # | File | Concept |
|---|------|---------|
| 21 | print_all_subsets.cpp | Power set generation |
| 22 | permutations_of_string.cpp | Swap-based backtracking |
| 23 | permutations_with_duplicates.cpp | Backtracking with duplicate pruning |
| 24 | combination_sum.cpp | Unbounded knapsack-style backtracking |
| 25 | combination_sum_ii.cpp | Bounded backtracking with dedup |
| 26 | generate_parentheses.cpp | Constrained recursion (Catalan numbers) |
| 27 | n_queens.cpp | Classic constraint-satisfaction backtracking |
| 28 | rat_in_a_maze.cpp | Grid pathfinding via backtracking |
| 29 | sudoku_solver.cpp | Constraint propagation + backtracking |
| 30 | word_search.cpp | Grid DFS with backtracking |

### `04_trees_divide_conquer/` — Recursive structures & D&C algorithms (10 problems)
| # | File | Concept |
|---|------|---------|
| 31 | binary_tree_inorder.cpp | Tree traversal (L-Root-R) |
| 32 | binary_tree_preorder.cpp | Tree traversal (Root-L-R) |
| 33 | binary_tree_postorder.cpp | Tree traversal (L-R-Root) |
| 34 | height_of_binary_tree.cpp | Bottom-up recursive computation |
| 35 | diameter_of_binary_tree.cpp | Bottom-up recursion with side-channel state |
| 36 | path_sum_binary_tree.cpp | Top-down recursion with target reduction |
| 37 | merge_sort.cpp | Divide and conquer (Master Theorem case 2) |
| 38 | quick_sort.cpp | Divide and conquer (in-place partitioning) |
| 39 | binary_search_recursive.cpp | Divide and conquer (Master Theorem case 1) |
| 40 | tower_of_hanoi.cpp | The archetypal recursion problem |

## Compiling any file
```bash
g++ -std=c++17 -o solution <filename>.cpp
./solution
```

## Suggested next steps
- Add a `05_memoization/` folder converting the exponential solutions
  (Fibonacci, Combination Sum, Subsequence Sum) into top-down DP.
- Add LeetCode problem number references as comments for cross-linking.
